var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/do8zla');

module.exports = mongoose;